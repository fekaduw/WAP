import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/page2")
public class Page2Servlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        boolean isLoggedIn = session!=null && session.getAttribute("user-name")!=null && session.getAttribute("password")!=null;

        if(isLoggedIn){
            req.getRequestDispatcher("page2.jsp").forward(req, resp);

            System.out.println("Session..."+ session.getAttribute("user-name"));
            System.out.println("Cookies..."+ req.getCookies()[0].getValue());
        }
        else {
            System.out.println("no session...");
            resp.sendRedirect("index.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
