import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Page2Servlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if(req.getSession().getAttribute("user-name")!=null && req.getSession().getAttribute("password")!=null){
            req.getRequestDispatcher("page2.jsp").forward(req, resp);

            System.out.println("Session..."+ req.getSession().getAttribute("user-name"));

        }
        else {
            System.out.println("no session...");
            resp.sendRedirect("index");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if(req.getSession().getAttribute("user-name")!=null && req.getSession().getAttribute("password")!=null){
            req.getRequestDispatcher("page2.jsp").forward(req, resp);

            System.out.println("Session..."+ req.getSession().getAttribute("user-name"));

        }
        else {
            System.out.println("no session...");
            resp.sendRedirect("index");
        }
    }
}
