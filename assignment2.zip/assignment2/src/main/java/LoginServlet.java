import com.sun.net.httpserver.HttpsParameters;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String userName = req.getParameter("user_name");
        String password = req.getParameter("password");

        HttpSession session = req.getSession();

        if (UserMapping.checkUser(userName, password)) {
            session.setAttribute("user-name", userName);
            session.setAttribute("password", password);
            session.setMaxInactiveInterval(5);

            req.getRequestDispatcher("/page2").forward(req, resp);
        }
        else {
            session.setAttribute("error", "Invalid user name or password.");
            resp.sendRedirect("index.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

            resp.sendRedirect("index.jsp");

    }
}
