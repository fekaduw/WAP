import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String userName = req.getParameter("user_name");
        String password = req.getParameter("password");
        boolean isRememberMeSelected = req.getParameter("rememberme") != null;

        HttpSession session = req.getSession();

        if (UserMapping.checkUser(userName, password)) {
            session.setAttribute("user-name", userName);
            session.setAttribute("password", password);

            if (isRememberMeSelected) {
                Cookie cookieUserName = new Cookie("user-name", userName);
                cookieUserName.setMaxAge(60 * 60 * 24 * 30);
                resp.addCookie(cookieUserName);

                Cookie cookiePassword = new Cookie("password", password);
                cookiePassword.setMaxAge(60 * 60 * 24 * 30);
                resp.addCookie(cookiePassword);

                Cookie remembermeCookie = new Cookie("rememberme", isRememberMeSelected?"true":"false");
                remembermeCookie.setMaxAge(60 * 60 * 24 * 30);
                resp.addCookie(remembermeCookie);

                //promo is persistent cookie
                Cookie promoCookie = new Cookie("promo", "$100");
                remembermeCookie.setMaxAge(60 * 60 * 24 * 30);
                resp.addCookie(promoCookie);
            } else {
                Cookie[] cookies = req.getCookies();
                if (cookies != null) {
                    for (Cookie cookie : cookies) {
                        if(cookie.getName().equals("promo")) continue; //don't delete promo as it is a persistent cookie

                        cookie.setValue("");
                        cookie.setMaxAge(0);
                        resp.addCookie(cookie);
                    }
                }
            }

            req.getRequestDispatcher("/page2").forward(req, resp);
        } else {
            session.setAttribute("error", "Invalid user name or password.");
            req.getRequestDispatcher("index.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    }
}
