public class User {
    private String userName;

    private String password;


    String getUserName() {
        return userName;
    }

    String getPassword() {
        return password;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
