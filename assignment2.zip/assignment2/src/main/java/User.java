public class User {
    private String userName;
    private String password;

    public User(){
        this.userName = "admin";
        this.password = "123456";
    }

    String getUserName(){
        return userName;
    }

    String getPassword(){
        return password;
    }
}
