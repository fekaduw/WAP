import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(filterName = "/page2")
public class LoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpSession session = request.getSession(false);

        boolean isLoggedIn = session != null && session.getAttribute("user-name") != null && session.getAttribute("password") != null;
        String loginURI = request.getContextPath() + "/login";
        boolean isLoginRequest = request.getRequestURI().equals(loginURI);
        boolean isLoginPage = request.getRequestURI().endsWith("index.jsp");


        if (isLoggedIn && (isLoginRequest || isLoginPage)) {
            request.getRequestDispatcher("page2").forward(request, resp);
        } else if (isLoggedIn && isLoginRequest) {
            chain.doFilter(req, resp);
        } else {
            request.getRequestDispatcher("index.jsp").forward(request, resp);
        }
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
