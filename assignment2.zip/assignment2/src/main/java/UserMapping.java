public class UserMapping {
    public static boolean checkUser(String userName, String password){
        User user = new User();
        return user.getUserName().equals(userName) && user.getPassword().equals(password) ;
    }
}
