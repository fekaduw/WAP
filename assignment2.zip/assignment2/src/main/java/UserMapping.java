public class UserMapping {
    private static User user = new User();

    public static boolean checkUser(String userName, String password){
        addUser();
        return user.getUserName().equals(userName) && user.getPassword().equals(password) ;
    }

    private static void addUser(){
        user.setUserName("admin");
        user.setPassword("123456");
    }
}
